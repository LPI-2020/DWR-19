#ifndef __CMDPARSER_H__
#define __CMDPARSER_H__

/******************************************************************************
Function Prototypes
******************************************************************************/
extern char exec_cmd(const char *str);

#endif // !__CMDPARSER_H__
